# TODO: Fix Chat Template Error in MedGemma

## Steps to Complete
- [x] Define system_prompt variable in generate_chat_response function
- [x] Modify conversation history loop to prepend system_prompt to user messages
- [x] Modify current user message to prepend system_prompt
- [x] Remove the separate system message from messages list
- [ ] Test the chat functionality to verify error is resolved
